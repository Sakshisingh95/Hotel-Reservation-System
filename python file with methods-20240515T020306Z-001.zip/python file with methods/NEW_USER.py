# Create a class for user to be stored into the database

# Import db_base and csv to pythonfile
import db_base as db
import csv

#create class user with attributes of first name, last name and username
class User:
    def __init__(self, row):
        self.first_name = row[0]
        self.last_name = row[1]
        self.username = row[2]

# create usercsv class to read and load user data into database
class UserCSV(db.DBbase):

# create a reset or create database that creates
    def reset_or_create_db(self):

        try:
            sql = """
                DROP TABLE IF EXISTS User;

                CREATE TABLE User (
                    user_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
                    first_name TEXT,
                    last_name TEXT,
                    username TEXT UNIQUE
                );
            """

            super().execute_script(sql)

        except Exception as e:
            print(e)

#create method that reads user data from csv into table
    def read_user_data(self, file_name):
        self.user_data = []

        try:
            with open(file_name, 'r') as record:
                csv_contents = csv.reader(record)
                next(record)
                for row in csv_contents:
                    # print(row)
                    user = User(row)
                    self.user_data.append(user)
        except Exception as e:
            print(e)

# create method that commits a save of the csv to the database
    def save_to_database(self):
        print("Number of users to save: ", len(self.user_data))
        save = input("Continue? ").lower()

        if save == "y":
            for item in self.user_data:

                try:
                    super().get_cursor.execute("""INSERT OR IGNORE INTO User
                    (first_name, last_name, username)
                        VALUES (?,?,?)""",
                                               (item.first_name, item.last_name, item.username))

                    super().get_connection.commit()

                    print("Saved item: ", item.username)
                except Exception as e:
                    print(e)
        else:
            print("Save to DB aborted")

#TODO: Add Create, Retrieve, Update, and Delete Methods to User Class

    def create_user(self, first_name, last_name, username):
        try:
            super().get_cursor.execute("""
                INSERT INTO User (first_name, last_name, username)
                VALUES (?,?,?)
            """, (first_name, last_name, username))
            super().get_connection.commit()
            print("User created successfully.")
        except Exception as e:
            print(e)

    def retrieve_user(self, user_id):
        try:
            super().get_cursor.execute("""
                SELECT * FROM User WHERE user_id=?
            """, (user_id,))
            user_data = super().get_cursor.fetchall()
            if user_data:
                return user_data
            else:
                print("User not found.")
                return None
        except Exception as e:
            print(e)

    def update_user(self, user_id, first_name=None, last_name=None, username=None):
        try:
            update_query = "UPDATE User SET "
            params = []
            if first_name:
                update_query += "first_name=?, "
                params.append(first_name)
            if last_name:
                update_query += "last_name=?, "
                params.append(last_name)
            if username:
                update_query += "username=?, "
                params.append(username)
            update_query = update_query.rstrip(", ") + " WHERE user_id=?"
            params.append(user_id)

            super().get_cursor.execute(update_query, tuple(params))
            super().get_connection.commit()
            print("User updated successfully.")
        except Exception as e:
            print(e)

    def delete_user(self, user_id):
        try:
            super().get_cursor.execute("""
                DELETE FROM User WHERE user_id=?
            """, (user_id,))
            super().get_connection.commit()
            print("User deleted successfully.")
        except Exception as e:
            print(e)


# connect UserCSV to Hotel Project sqlite and initialize the CSV
hotel_project = UserCSV("HotelReservation.sqlite")
# hotel_project.reset_or_create_db()
# hotel_project.read_user_data("user.csv")
# hotel_project.save_to_database()