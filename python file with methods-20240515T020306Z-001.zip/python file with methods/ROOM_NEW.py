# File IO CSV Reading for Room

# Import db_base and csv to pythonfile
import db_base as db
import csv

# create class of room table for csv reader to read into database
class Room:

    def __init__(self, row):
        self.room_name = row[2]
        self.room_number = row[1]
        self.floor = row[3]
        self.beds = row[4]
        self.room_type = row[5]

# create class from dbbase that initiates room table in database from csv
class RoomCSV(db.DBbase):

# create a reset or create database that creates
    def reset_or_create_db(self):

        try:
            sql = """
                DROP TABLE IF EXISTS Room;

                CREATE TABLE Room (
                    room_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
                    room_number INTEGER,
                    room_name TEXT,
                    floor INTEGER,
                    beds INTEGER,
                    room_type TEXT
                );
            """

            super().execute_script(sql)

        except Exception as e:
            print(e)

#create method that reads room data from csv into table
    def read_room_data(self, file_name):
        self.room_data = []

        try:
            with open(file_name, 'r') as record:
                csv_contents = csv.reader(record)
                next(record)
                for row in csv_contents:
                    # print(row)
                    room = Room(row)
                    self.room_data.append(room)
        except Exception as e:
            print(e)

# create method that commits a save of the csv to the database
    def save_to_database(self):
        print("Number of rooms to save: ", len(self.room_data))
        save = input("Continue? ").lower()

        if save == "y":
            for item in self.room_data:

                try:
                    super().get_cursor.execute("""INSERT INTO Room
                    (room_number, room_name, floor, beds, room_type)
                        VALUES (?,?,?,?,?)""",
                                               (item.room_number, item.room_name, item.floor, item.beds, item.room_type))

                    super().get_connection.commit()

                    print("Saved item: ", item.room_number, item.room_name)
                except Exception as e:
                    print(e)
        else:
            print("Save to DB aborted")
#TODO 

    def create_room(self, room_number, room_name, floor, beds, room_type):
        try:
            super().get_cursor.execute("""
                INSERT INTO Room (room_number, room_name, floor, beds, room_type)
                VALUES (?,?,?,?,?)
            """, (room_number, room_name, floor, beds, room_type))
            super().get_connection.commit()
            print("Room created successfully.")
        except Exception as e:
            print(e)

    def retrieve_room(self, room_id):
        try:
            super().get_cursor.execute("""
                SELECT * FROM Room WHERE room_id=?
            """, (room_id,))
            room_data = super().get_cursor.fetchall()
            if room_data:
                return room_data
            else:
                print("Room not found.")
                return None
        except Exception as e:
            print(e)

    def update_room(self, room_id, room_number=None, room_name=None, floor=None, beds=None, room_type=None):
        try:
            update_query = "UPDATE Room SET "
            params = []
            if room_number:
                update_query += "room_number=?, "
                params.append(room_number)
            if room_name:
                update_query += "room_name=?, "
                params.append(room_name)
            if floor:
                update_query += "floor=?, "
                params.append(floor)
            if beds:
                update_query += "beds=?, "
                params.append(beds)
            if room_type:
                update_query += "room_type=?, "
                params.append(room_type)
            update_query = update_query.rstrip(", ") + " WHERE room_id=?"
            params.append(room_id)

            super().get_cursor.execute(update_query, tuple(params))
            super().get_connection.commit()
            print("Room updated successfully.")
        except Exception as e:
            print(e)

    def delete_room(self, room_id):
        try:
            super().get_cursor.execute("""
                DELETE FROM Room WHERE room_id=?
            """, (room_id,))
            super().get_connection.commit()
            print("Room deleted successfully.")
        except Exception as e:
            print(e)

# connect RoomCSV to Hotel Project sqlite and initialize the CSV
hotel_project = RoomCSV("HotelReservation.sqlite")
# hotel_project.reset_or_create_db()
hotel_project.read_room_data("room.csv")
hotel_project.save_to_database()