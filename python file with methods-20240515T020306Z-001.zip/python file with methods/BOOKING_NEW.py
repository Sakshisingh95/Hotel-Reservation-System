# File IO CSV Reading for Room

# Import db_base, room and csv to pythonfile
import db_base as db
import csv
import room

# create class of room table for csv reader to read into database
class Booking:

    def __init__(self, row):
        self.room_id = row[1]
        self.start_date = row[2]
        self.end_date = row[3]

# create class from dbbase that initiates room table in database from csv
class BookingCSV(db.DBbase):

# create a reset or create database that creates
    def reset_or_create_db(self):

        try:
            sql = """
                DROP TABLE IF EXISTS Booking;

                CREATE TABLE Booking (
                    booking_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,
                    room_id INTEGER NOT NULL,
                    start_date DATE,
                    end_date DATE
                );
            """

            super().execute_script(sql)

        except Exception as e:
            print(e)

#create method that reads booking data from csv into table
    def read_booking_data(self, file_name):
        self.booking_data = []

        try:
            with open(file_name, 'r') as record:
                csv_contents = csv.reader(record)
                next(record)
                for row in csv_contents:
                    # print(row)
                    booking = Booking(row)
                    self.booking_data.append(booking)
        except Exception as e:
            print(e)

# create method that commits a save of the csv to the database
    def save_to_database(self):
        print("Number of bookings to save: ", len(self.booking_data))
        save = input("Continue? ").lower()

        if save == "y":
            for item in self.booking_data:
                try:
                    super().get_cursor.execute("""INSERT OR IGNORE INTO Booking
                    (room_id, start_date, end_date)
                        VALUES (?,?,?)""",
                                               (item.room_id, item.start_date, item.end_date))

                    super().get_connection.commit()

                    print("Saved item: ", item.room_id, item.start_date, item.end_date)
                except Exception as e:
                    print(e)
        else:
            print("Save to DB aborted")

    def create_booking(self, room_id, start_date, end_date):
        try:
            super().get_cursor.execute("""
                INSERT INTO Booking (room_id, start_date, end_date)
                VALUES (?,?,?)
            """, (room_id, start_date, end_date))
            super().get_connection.commit()
            print("Booking created successfully.")
        except Exception as e:
            print(e)

    def retrieve_booking(self, booking_id):
        try:
            super().get_cursor.execute("""
                SELECT * FROM Booking WHERE booking_id=?
            """, (booking_id,))
            booking_data = super().get_cursor.fetchall()
            if booking_data:
                return booking_data
            else:
                print("Booking not found.")
                return None
        except Exception as e:
            print(e)

    def update_booking(self, booking_id, room_id=None, start_date=None, end_date=None):
        try:
            update_query = "UPDATE Booking SET "
            params = []
            if room_id:
                update_query += "room_id=?, "
                params.append(room_id)
            if start_date:
                update_query += "start_date=?, "
                params.append(start_date)
            if end_date:
                update_query += "end_date=?, "
                params.append(end_date)
            update_query = update_query.rstrip(", ") + " WHERE booking_id=?"
            params.append(booking_id)

            super().get_cursor.execute(update_query, tuple(params))
            super().get_connection.commit()
            print("Booking updated successfully.")
        except Exception as e:
            print(e)

    def delete_booking(self, booking_id):
        try:
            super().get_cursor.execute("""
                DELETE FROM Booking WHERE booking_id=?
            """, (booking_id,))
            super().get_connection.commit()
            print("Booking deleted successfully.")
        except Exception as e:
            print(e)


#connect BookingCSV to Hotel Project sqlite and initialize the CSV
hotel_project = BookingCSV("HotelReservation.sqlite")
# hotel_project.reset_or_create_db()
# hotel_project.read_booking_data("booking.csv")
# hotel_project.save_to_database()